//CREDIT: https://github.com/SkyCrypt/SkyCryptWebsite
module.exports = {
    pond_squid: "Squid",
    unburried_zombie: "Crypt Ghoul",
    zealot_enderman: "Zealot",
    invisible_creeper: "Sneaky Creeper",
    generator_ghast: "Minion Ghast",
    generator_magma_cube: "Minion Magma Cube",
    generator_slime: "Minion Slime",
    brood_mother_spider: "Brood Mother",
    obsidian_wither: "Obsidian Defender",
    sadan_statue: "Terracotta",
    diamond_guy: "Angry Archaeologist",
    tentaclees: "Fels",
    master_diamond_guy: "Master Angry Archaeologist",
    master_sadan_statue: "Master Terracotta",
    master_tentaclees: "Master Fels",
    maxor: "Necron",
}